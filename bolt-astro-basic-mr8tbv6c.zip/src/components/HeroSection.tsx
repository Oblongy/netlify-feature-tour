import { motion } from 'framer-motion';

export default function HeroSection() {
  return (
    <section className="min-h-screen pt-20 flex items-center">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 2 }}
          className="text-center"
        >
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            <span className="metal-gradient">DOMINATE THE</span>
            <span className="text-racing-red red-glow"> TRACK</span>
          </h1>
          <p className="text-lg md:text-xl text-gray-300 mb-8">
            Join the elite team of drag racing champions
          </p>
          <div className="flex justify-center gap-4">
            <a
              href="/brackets"
              className="bg-racing-red text-white px-8 py-3 rounded-md hover:bg-red-700 transition-colors"
            >
              Tournament Brackets
            </a>
            <a
              href="/gear-calculator"
              className="bg-metal text-racing-black px-8 py-3 rounded-md hover:bg-gray-300 transition-colors"
            >
              Gear Calculator
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}