import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface GearData {
  Gear: number;
  Ratio: number;
  RedlineRPM?: number;
}

interface TransmissionConfig {
  FirstGear: number;
  NumGears: number;
  CustomDrops: number[];
  RedlineRPM: number;
}

const DefaultDropPercentages: Record<number, number[]> = {
  6: [0.353, 0.289, 0.243, 0.214, 0.181],
  5: [0.353, 0.289, 0.243, 0.214]
};

const MIN_RATIO = 0.48;
const MAX_RATIO = 6.00;
const DEFAULT_REDLINE = 7500;

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      type: "spring",
      stiffness: 100
    }
  }
};

const pulseAnimation = {
  scale: [1, 1.02, 1],
  transition: {
    duration: 2,
    repeat: Infinity,
    ease: "easeInOut"
  }
};

export default function GearCalculator() {
  const [config, setConfig] = useState<TransmissionConfig>({
    FirstGear: 2.97,
    NumGears: 6,
    CustomDrops: [...DefaultDropPercentages[6]],
    RedlineRPM: DEFAULT_REDLINE
  });
  const [gearData, setGearData] = useState<GearData[]>([]);
  const [isCalculating, setIsCalculating] = useState(false);
  const [error, setError] = useState<string>('');

  const calculateGearRatios = (firstGear: number, numGears: number, customDrops: number[], redlineRPM: number): number[] | null => {
    if (firstGear < MIN_RATIO || firstGear > MAX_RATIO) {
      setError(`First gear ratio must be between ${MIN_RATIO} and ${MAX_RATIO}`);
      return null;
    }

    const ratios = [firstGear];
    const drops = customDrops;

    for (let i = 1; i < numGears; i++) {
      const previousGear = ratios[i - 1];
      const dropPercentage = drops[i - 1];
      const newRatio = previousGear * (1 - dropPercentage);
      
      if (newRatio < MIN_RATIO) {
        setError(`Gear ${i + 1} ratio (${newRatio.toFixed(2)}) would be below minimum ${MIN_RATIO}`);
        return null;
      }
      
      if (newRatio > MAX_RATIO) {
        setError(`Gear ${i + 1} ratio (${newRatio.toFixed(2)}) would exceed maximum ${MAX_RATIO}`);
        return null;
      }

      ratios.push(Number(newRatio.toFixed(2)));
    }

    return ratios;
  };

  const handleGearChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    
    if (name === "NumGears") {
      const numGears = Number(value);
      setConfig(prev => ({
        ...prev,
        NumGears: numGears,
        CustomDrops: [...DefaultDropPercentages[numGears]]
      }));
    } else {
      setConfig(prev => ({
        ...prev,
        [name]: Number(value)
      }));
    }
    
    setError('');
  };

  const calculateRatios = async () => {
    setError('');
    setIsCalculating(true);
    const ratios = calculateGearRatios(config.FirstGear, config.NumGears, config.CustomDrops, config.RedlineRPM);
    
    if (!ratios) {
      setIsCalculating(false);
      return;
    }

    const newGearData = ratios.map((ratio, index) => ({
      Gear: index + 1,
      Ratio: ratio,
      RedlineRPM: (config.RedlineRPM / ratio).toFixed(0)
    }));

    await new Promise(resolve => setTimeout(resolve, 500));
    setGearData(newGearData);
    setIsCalculating(false);
  };

  return (
    <div className="max-w-6xl mx-auto">
      <motion.div 
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="panel rounded-lg p-8 mb-8 border-2 border-racing-red/30"
      >
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-3 gap-6"
          variants={containerVariants}
        >
          <motion.div 
            variants={itemVariants}
            whileHover={{ scale: 1.02 }}
            className="panel rounded-lg p-6 bg-black/40 backdrop-blur-sm border border-racing-red/20"
          >
            <label className="block text-racing-red mb-3 text-lg font-bold">Number of Gears</label>
            <select
              name="NumGears"
              value={config.NumGears}
              onChange={handleGearChange}
              className="input-field w-full rounded-lg px-4 py-3 bg-black/60"
            >
              <option value={5}>5 Speed</option>
              <option value={6}>6 Speed</option>
            </select>
          </motion.div>

          <motion.div 
            variants={itemVariants}
            whileHover={{ scale: 1.02 }}
            className="panel rounded-lg p-6 bg-black/40 backdrop-blur-sm border border-racing-red/20"
          >
            <label className="block text-racing-red mb-3 text-lg font-bold">
              First Gear Ratio ({MIN_RATIO} - {MAX_RATIO})
            </label>
            <input
              type="number"
              name="FirstGear"
              value={config.FirstGear}
              onChange={handleGearChange}
              onBlur={() => calculateRatios()}
              className="input-field w-full rounded-lg px-4 py-3 bg-black/60"
              step="0.01"
              min={MIN_RATIO}
              max={MAX_RATIO}
            />
          </motion.div>

          <motion.div 
            variants={itemVariants}
            whileHover={{ scale: 1.02 }}
            className="panel rounded-lg p-6 bg-black/40 backdrop-blur-sm border border-racing-red/20"
          >
            <label className="block text-racing-red mb-3 text-lg font-bold">
              Redline RPM x1000
            </label>
            <input
              type="number"
              name="RedlineRPM"
              value={config.RedlineRPM / 1000}
              onChange={(e) => {
                const value = Number(e.target.value) * 1000;
                handleGearChange({
                  target: { name: 'RedlineRPM', value: value.toString() }
                } as React.ChangeEvent<HTMLInputElement>);
              }}
              onBlur={() => calculateRatios()}
              className="input-field w-full rounded-lg px-4 py-3 bg-black/60"
              step="0.1"
              min="3"
              max="15"
            />
          </motion.div>
        </motion.div>

        {error && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="mt-4 p-4 bg-racing-red/20 border border-racing-red rounded-lg text-white"
          >
            {error}
          </motion.div>
        )}

        <motion.button
          onClick={calculateRatios}
          className="red-button mt-8 rounded-lg w-full md:w-auto px-8 py-4 text-lg uppercase tracking-wider font-bold"
          whileHover={{ scale: 1.05, boxShadow: "0 0 15px rgba(255,0,0,0.5)" }}
          whileTap={{ scale: 0.95 }}
          animate={isCalculating ? pulseAnimation : {}}
          disabled={isCalculating}
        >
          {isCalculating ? 'Calculating...' : 'Calculate Ratios'}
        </motion.button>
      </motion.div>

      <AnimatePresence mode="wait">
        {gearData.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            transition={{ type: "spring", stiffness: 100 }}
          >
            <motion.div 
              className="panel rounded-lg p-8 border-2 border-racing-red/30 bg-black/40 backdrop-blur-sm mb-8"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              <motion.h2 
                variants={itemVariants}
                className="text-2xl font-bold text-racing-red mb-6"
              >
                Calculated Gear Ratios
              </motion.h2>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                {gearData.map((gear, index) => (
                  <motion.div
                    key={gear.Gear}
                    variants={itemVariants}
                    whileHover={{ 
                      scale: 1.05,
                      boxShadow: "0 0 15px rgba(255,0,0,0.3)"
                    }}
                    custom={index}
                    className="panel rounded-lg p-4 bg-black/60 border border-racing-red/20 text-center"
                  >
                    <div className="text-racing-red font-bold mb-2">Gear {gear.Gear}</div>
                    <div className="text-2xl font-bold text-white mb-2">{gear.Ratio.toFixed(2)}:1</div>
                    <div className="text-sm text-gray-400">
                      RPM x1000: {(Number(gear.RedlineRPM) / 1000).toFixed(1)}
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}