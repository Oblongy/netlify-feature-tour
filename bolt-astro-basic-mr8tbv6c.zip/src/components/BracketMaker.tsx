import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface Participant {
  id: string;
  name: string;
  dialIn: string;
  reaction: string;
  seed?: number;
  winner?: boolean;
  wins?: number;
  losses?: number;
}

interface BracketConfig {
  name: string;
  type: 'H2H' | 'Single Elimination' | 'Double Elimination';
  description: string;
}

interface Match {
  id: string;
  round: number;
  position: number;
  participants: [Participant | null, Participant | null];
  winner: Participant | null;
  nextMatchId: string | null;
}

export default function BracketMaker() {
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [newParticipant, setNewParticipant] = useState({ name: '', dialIn: '', reaction: '' });
  const [matches, setMatches] = useState<Match[]>([]);
  const [config, setConfig] = useState<BracketConfig>({
    name: 'Untitled Tournament',
    type: 'Single Elimination',
    description: ''
  });
  const [tournamentComplete, setTournamentComplete] = useState(false);
  const [winner, setWinner] = useState<Participant | null>(null);
  const [currentH2HMatch, setCurrentH2HMatch] = useState<[Participant | null, Participant | null]>([null, null]);

  const advanceWinner = (match: Match, winner: Participant) => {
    const updatedMatches = [...matches];
    const currentMatch = updatedMatches.find(m => m.id === match.id);
    
    if (!currentMatch) return;
    
    // Set winner for current match
    currentMatch.winner = winner;
    
    // If there's a next match, update its participants
    if (currentMatch.nextMatchId) {
      const nextMatch = updatedMatches.find(m => m.id === currentMatch.nextMatchId);
      if (nextMatch) {
        const position = currentMatch.position % 2 === 0 ? 0 : 1;
        nextMatch.participants[position] = winner;
      }
    } else {
      // This is the final match
      setTournamentComplete(true);
      setWinner(winner);
    }
    
    setMatches(updatedMatches);
  };

  const addParticipant = () => {
    if (newParticipant.name.trim()) {
      setParticipants([
        ...participants,
        {
          id: crypto.randomUUID(),
          name: newParticipant.name.trim(),
          dialIn: newParticipant.dialIn.trim(),
          reaction: newParticipant.reaction.trim(),
          seed: participants.length + 1,
          wins: 0,
          losses: 0
        }
      ]);
      setNewParticipant({ name: '', dialIn: '', reaction: '' });
    }
  };

  const startH2HMatch = () => {
    if (participants.length < 2) return;
    
    // Generate initial bracket with all participants
    const sortedParticipants = [...participants].sort((a, b) => (a.seed || 0) - (b.seed || 0));
    const totalRounds = Math.ceil(Math.log2(sortedParticipants.length));
    const totalMatches = Math.pow(2, totalRounds) - 1;
    
    const newMatches: Match[] = [];
    let matchCounter = 0;
    let participantCounter = 0;
    
    // Generate matches for each round
    for (let round = 0; round < totalRounds; round++) {
      const matchesInRound = Math.pow(2, totalRounds - round - 1);
      
      for (let position = 0; position < matchesInRound; position++) {
        const matchId = `match-${round}-${position}`;
        const nextMatchId = round < totalRounds - 1 
          ? `match-${round + 1}-${Math.floor(position / 2)}`
          : null;

        let participants: [Participant | null, Participant | null] = [null, null];
        
        if (round === 0) {
          participants = [
            sortedParticipants[participantCounter] || null,
            sortedParticipants[participantCounter + 1] || null
          ];
          participantCounter += 2;
        }

        newMatches.push({
          id: matchId,
          round,
          position,
          participants,
          winner: null,
          nextMatchId
        });
        
        matchCounter++;
      }
    }
    
    setMatches(newMatches);
    
    // Set the first match as current H2H match
    const firstMatch = newMatches[0];
    if (firstMatch && firstMatch.participants[0] && firstMatch.participants[1]) {
      setCurrentH2HMatch([firstMatch.participants[0], firstMatch.participants[1]]);
    }
  };

  const declareH2HWinner = (winner: Participant, loser: Participant) => {
    const updatedParticipants = participants.map(p => {
      if (p.id === winner.id) {
        return { ...p, wins: (p.wins || 0) + 1 };
      }
      if (p.id === loser.id) {
        return { ...p, losses: (p.losses || 0) + 1 };
      }
      return p;
    });
    
    setParticipants(updatedParticipants);
    
    // Update matches with the winner
    const currentMatchIndex = matches.findIndex(
      m => m.participants.some(p => p?.id === winner.id || p?.id === loser.id)
    );
    
    if (currentMatchIndex !== -1) {
      const updatedMatches = [...matches];
      const currentMatch = updatedMatches[currentMatchIndex];
      currentMatch.winner = winner;
      
      // Find and update next match if it exists
      if (currentMatch.nextMatchId) {
        const nextMatch = updatedMatches.find(m => m.id === currentMatch.nextMatchId);
        if (nextMatch) {
          const position = currentMatch.position % 2 === 0 ? 0 : 1;
          nextMatch.participants[position] = winner;
          
          // Set next match as current H2H match if both participants are present
          if (nextMatch.participants[0] && nextMatch.participants[1]) {
            setCurrentH2HMatch([nextMatch.participants[0], nextMatch.participants[1]]);
          } else {
            setCurrentH2HMatch([null, null]);
          }
        }
      } else {
        // Tournament is complete
        setTournamentComplete(true);
        setWinner(winner);
        setCurrentH2HMatch([null, null]);
      }
      
      setMatches(updatedMatches);
    }
  };

  const generateBracket = () => {
    if (participants.length < 2) return;
    
    const sortedParticipants = [...participants].sort((a, b) => (a.seed || 0) - (b.seed || 0));
    const totalRounds = Math.ceil(Math.log2(sortedParticipants.length));
    const totalMatches = Math.pow(2, totalRounds) - 1;
    
    const newMatches: Match[] = [];
    let matchCounter = 0;
    let participantCounter = 0;
    
    // Generate matches for each round
    for (let round = 0; round < totalRounds; round++) {
      const matchesInRound = Math.pow(2, totalRounds - round - 1);
      
      for (let position = 0; position < matchesInRound; position++) {
        const matchId = `match-${round}-${position}`;
        const nextMatchId = round < totalRounds - 1 
          ? `match-${round + 1}-${Math.floor(position / 2)}`
          : null;

        let participants: [Participant | null, Participant | null] = [null, null];
        
        if (round === 0) {
          participants = [
            sortedParticipants[participantCounter] || null,
            sortedParticipants[participantCounter + 1] || null
          ];
          participantCounter += 2;
        }

        newMatches.push({
          id: matchId,
          round,
          position,
          participants,
          winner: null,
          nextMatchId
        });
        
        matchCounter++;
      }
    }
    
    setMatches(newMatches);
    setTournamentComplete(false);
    setWinner(null);
  };

  const declareWinner = (matchId: string, winner: Participant) => {
    const updatedMatches = matches.map(match => {
      if (match.id === matchId) {
        return { ...match, winner };
      }
      
      if (match.id === match.nextMatchId) {
        const position = match.position % 2 === 0 ? 0 : 1;
        const updatedParticipants = [...match.participants] as [Participant | null, Participant | null];
        updatedParticipants[position] = winner;
        return { ...match, participants: updatedParticipants };
      }
      
      return match;
    });

    // Check if tournament is complete
    const finalMatch = updatedMatches.find(m => m.nextMatchId === null);
    if (finalMatch && finalMatch.winner) {
      setTournamentComplete(true);
      setWinner(finalMatch.winner);
    }

    setMatches(updatedMatches);
  };

  return (
    <div className="flex min-h-screen">
      {/* Left Sidebar */}
      <div className="w-80 bg-black/40 border-r border-racing-red/20 p-6 flex flex-col gap-6">
        <div>
          <h2 className="text-xl font-bold text-racing-red mb-4">TOURNAMENT INFORMATION</h2>
          <div className="space-y-4">
            <div>
              <label className="block text-gray-400 mb-2">Tournament Name</label>
              <input
                type="text"
                value={config.name}
                onChange={(e) => setConfig({ ...config, name: e.target.value })}
                className="w-full bg-black/60 border border-racing-red/30 rounded px-3 py-2 text-white"
              />
            </div>
            <div>
              <label className="block text-gray-400 mb-2">Tournament Type</label>
              <select
                value={config.type}
                onChange={(e) => setConfig({ ...config, type: e.target.value as any })}
                className="w-full bg-black/60 border border-racing-red/30 rounded px-3 py-2 text-white"
              >
                <option value="H2H">Head to Head</option>
                <option value="Single Elimination">Single Elimination</option>
                <option value="Double Elimination">Double Elimination</option>
              </select>
            </div>
            <div>
              <label className="block text-gray-400 mb-2">Description</label>
              <textarea
                value={config.description}
                onChange={(e) => setConfig({ ...config, description: e.target.value })}
                className="w-full bg-black/60 border border-racing-red/30 rounded px-3 py-2 text-white h-24"
              />
            </div>
          </div>
        </div>

        <div>
          <h2 className="text-xl font-bold text-racing-red mb-4">ADD PARTICIPANT</h2>
          <div className="space-y-4">
            <input
              type="text"
              placeholder="Driver Name"
              value={newParticipant.name}
              onChange={(e) => setNewParticipant({ ...newParticipant, name: e.target.value })}
              className="w-full bg-black/60 border border-racing-red/30 rounded px-3 py-2 text-white"
            />
            <input
              type="text"
              placeholder="Dial-In Time"
              value={newParticipant.dialIn}
              onChange={(e) => setNewParticipant({ ...newParticipant, dialIn: e.target.value })}
              className="w-full bg-black/60 border border-racing-red/30 rounded px-3 py-2 text-white"
            />
            <input
              type="text"
              placeholder="Reaction Time"
              value={newParticipant.reaction}
              onChange={(e) => setNewParticipant({ ...newParticipant, reaction: e.target.value })}
              className="w-full bg-black/60 border border-racing-red/30 rounded px-3 py-2 text-white"
            />
            <button
              onClick={addParticipant}
              className="w-full bg-racing-red text-white py-2 rounded font-bold hover:bg-red-700 transition-colors"
            >
              Add Driver
            </button>
          </div>
        </div>

        <div>
          <h2 className="text-xl font-bold text-racing-red mb-4">PARTICIPANTS ({participants.length})</h2>
          <div className="space-y-2 max-h-[300px] overflow-y-auto">
            {participants.map((participant, index) => (
              <motion.div
                key={participant.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="bg-black/20 border border-racing-red/20 rounded p-3"
              >
                <div className="flex justify-between items-center">
                  <span className="text-white">
                    <span className="text-racing-red mr-2">#{index + 1}</span>
                    {participant.name}
                  </span>
                  {config.type === 'H2H' && (
                    <span className="text-sm text-gray-400">
                      W: {participant.wins || 0} L: {participant.losses || 0}
                    </span>
                  )}
                  <button
                    onClick={() => setParticipants(participants.filter(p => p.id !== participant.id))}
                    className="text-racing-red hover:text-red-700"
                  >
                    ×
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        <button
          onClick={config.type === 'H2H' ? startH2HMatch : generateBracket}
          disabled={participants.length < 2}
          className={`mt-auto bg-racing-red text-white py-3 rounded-lg font-bold ${
            participants.length < 2 ? 'opacity-50 cursor-not-allowed' : 'hover:bg-red-700'
          }`}
        >
          {config.type === 'H2H' ? 'Start New Match' : 'Generate Bracket'}
        </button>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 p-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white">
            {config.name}
            <span className="text-racing-red ml-4 text-2xl">
              {config.type}
            </span>
          </h1>
        </div>

        {/* Current H2H Match Display */}
        {config.type === 'H2H' && currentH2HMatch[0] && currentH2HMatch[1] && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <div className="flex justify-center items-center gap-8">
              {currentH2HMatch.map((driver, index) => (
                <motion.div
                  key={driver?.id}
                  className="w-64 bg-black/40 border border-racing-red/20 rounded-lg p-6 relative"
                  whileHover={{ scale: 1.05 }}
                >
                  <h3 className="text-2xl font-bold text-white mb-2">{driver?.name}</h3>
                  <div className="text-sm text-gray-400">
                    <p>Dial-In: {driver?.dialIn}</p>
                    <p>RT: {driver?.reaction}</p>
                    <p>W/L: {driver?.wins}/{driver?.losses}</p>
                  </div>
                  <button
                    onClick={() => declareH2HWinner(
                      currentH2HMatch[index]!,
                      currentH2HMatch[1 - index]!
                    )}
                    className="mt-4 bg-racing-red text-white px-4 py-2 rounded w-full hover:bg-red-700"
                  >
                    Winner
                  </button>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Tournament Bracket Display */}
        {matches.length > 0 && (
          <div className="relative">
            {/* Winner Display */}
            {tournamentComplete && winner && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-full mb-8 p-6 bg-racing-red/20 border-2 border-racing-red rounded-lg text-center"
              >
                <h2 className="text-3xl font-bold text-white mb-2">🏆 Tournament Winner 🏆</h2>
                <p className="text-2xl text-racing-red font-bold">{winner.name}</p>
                <div className="mt-2 text-gray-300">
                  <span className="mr-4">Dial-In: {winner.dialIn}</span>
                  <span>Reaction: {winner.reaction}</span>
                </div>
              </motion.div>
            )}

            {/* Bracket Structure */}
            <div className="flex gap-16 overflow-x-auto pb-8">
              {Array.from(new Set(matches.map(m => m.round))).map(round => (
                <div
                  key={round}
                  className="flex flex-col gap-32"
                  style={{
                    marginTop: `${round * 64}px`
                  }}
                >
                  <div className="text-racing-red font-bold mb-4">
                    Round {round + 1}
                  </div>
                  {matches
                    .filter(m => m.round === round)
                    .map(match => (
                      <motion.div
                        key={match.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="relative"
                      >
                        <div className={`w-64 bg-black/40 border ${
                          match.winner ? 'border-racing-red' : 'border-racing-red/20'
                        } rounded-lg p-4`}>
                          {match.participants.map((participant, idx) => (
                            <div
                              key={participant?.id || idx}
                              className={`p-2 ${idx === 0 ? 'border-b border-racing-red/20' : ''} relative group`}
                            >
                              {participant ? (
                                <>
                                  <div className="flex items-center gap-2">
                                    <span className="text-racing-red font-bold">
                                      #{participant.seed || '-'}
                                    </span>
                                    <span className={`font-bold ${
                                      match.winner?.id === participant.id ? 'text-racing-red' : 'text-white'
                                    }`}>
                                      {participant.name}
                                    </span>
                                  </div>
                                  <div className="flex gap-4 text-sm text-gray-400">
                                    <span>Dial-In: {participant.dialIn}</span>
                                    <span>RT: {participant.reaction}</span>
                                  </div>
                                  {!match.winner && (
                                    <button
                                      onClick={() => advanceWinner(match, participant)}
                                      className="opacity-0 group-hover:opacity-100 absolute right-2 top-1/2 transform -translate-y-1/2 bg-racing-red text-white px-3 py-1 rounded text-sm hover:bg-red-700 transition-all"
                                    >
                                      Winner
                                    </button>
                                  )}
                                </>
                              ) : (
                                <div className="h-12 flex items-center text-gray-500">
                                  TBD
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                        
                        {/* Connector Lines */}
                        {match.nextMatchId && (
                          <div className="absolute top-1/2 -right-16 w-16 h-px bg-racing-red/30" />
                        )}
                      </motion.div>
                    ))}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}