import { motion } from 'framer-motion';

interface TeamMember {
  name: string;
  role: string;
  achievements?: string[];
  stats?: {
    bestET?: string;
    bestSpeed?: string;
    division?: string;
  };
}

export default function TeamGrid() {
  const teamMembers: TeamMember[] = [
    {
      name: 'VENOM',
      role: 'LEADER',
      achievements: ['2023 Division 4 Champion', 'Super Pro ET Champion'],
      stats: {
        bestET: '8.90',
        bestSpeed: '149.86',
        division: 'Super Pro ET'
      }
    },
    {
      name: 'GR3DDY',
      role: 'CO-LEADER',
      achievements: ['Texas Motorplex Track Champion', '2023 Quick 8 Winner'],
      stats: {
        bestET: '9.12',
        bestSpeed: '145.32',
        division: 'Pro ET'
      }
    },
    {
      name: 'OBLONG',
      role: 'RECRUITER',
      achievements: ['Former PDRA Pro Nitrous Driver', '2022 Outlaw 10.5 Champion'],
      stats: {
        bestET: '9.05',
        bestSpeed: '147.23',
        division: 'Pro ET'
      }
    },
    {
      name: 'PLAYERNERFED',
      role: 'MEMBER',
      achievements: ['2023 Rookie of the Year', 'Perfect RT Challenge Winner'],
      stats: {
        bestET: '10.15',
        bestSpeed: '132.45',
        division: 'Sportsman'
      }
    },
    {
      name: 'STACKINPAPER',
      role: 'MEMBER',
      achievements: ['Street Car Super Nationals Runner-up', 'Consistent 10-Second Passes'],
      stats: {
        bestET: '10.02',
        bestSpeed: '135.67',
        division: 'Sportsman'
      }
    },
    {
      name: 'JESSEK410',
      role: 'MEMBER',
      achievements: ['2023 Street Car Takeover Winner', 'Back-to-Back 9-Second Passes'],
      stats: {
        bestET: '9.85',
        bestSpeed: '138.92',
        division: 'Pro ET'
      }
    },
    {
      name: 'THEJ0K3R',
      role: 'MEMBER',
      achievements: ['No Prep Kings Invitational Runner-up', 'Small Tire Shootout Champion'],
      stats: {
        bestET: '9.32',
        bestSpeed: '142.15',
        division: 'Pro ET'
      }
    },
    {
      name: 'MR.GHOST',
      role: 'MEMBER',
      achievements: ['Midnight Madness Series Champion', 'Consistent Pro Tree Specialist'],
      stats: {
        bestET: '9.45',
        bestSpeed: '141.78',
        division: 'Pro ET'
      }
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto px-4">
      {teamMembers.map((member) => (
        <motion.div
          key={member.name}
          initial={{ opacity: 0, y: 20 }}
          whileHover={{ scale: 1.02, transition: { duration: 0.2 } }}
          animate={{ opacity: 1, y: 0 }}
          className="relative bg-gradient-to-br from-racing-black to-gray-900 border-2 border-racing-red rounded-lg p-8 text-center transform transition-all duration-300 hover:shadow-[0_0_20px_rgba(255,0,0,0.3)]"
        >
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-racing-red to-transparent"></div>
          <h2 className="text-4xl font-bold mb-4">
            <span className="metal-gradient">{member.name}</span>
          </h2>
          <div className="h-px w-full bg-gradient-to-r from-transparent via-racing-red to-transparent mb-4"></div>
          <p className="text-racing-red text-2xl font-bold mb-4">{member.role}</p>
          {member.stats && (
            <div className="grid grid-cols-2 gap-4 mb-6 text-sm">
              <div className="bg-racing-black/50 p-2 rounded">
                <p className="text-gray-400">Best ET</p>
                <p className="text-white font-bold">{member.stats.bestET}s</p>
              </div>
              <div className="bg-racing-black/50 p-2 rounded">
                <p className="text-gray-400">Top Speed</p>
                <p className="text-white font-bold">{member.stats.bestSpeed} MPH</p>
              </div>
              <div className="col-span-2 bg-racing-black/50 p-2 rounded">
                <p className="text-gray-400">Division</p>
                <p className="text-white font-bold">{member.stats.division}</p>
              </div>
            </div>
          )}
          {member.achievements && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="text-sm text-gray-400 space-y-2"
            >
              {member.achievements.map((achievement, index) => (
                <p key={index} className="italic">• {achievement}</p>
              ))}
            </motion.div>
          )}
          <div className="absolute bottom-0 right-0 w-full h-1 bg-gradient-to-r from-transparent via-racing-red to-transparent"></div>
        </motion.div>
      ))}
    </div>
  );
}