import { useEffect, useRef } from 'react';
import gsap from 'gsap';

export default function IntroAnimation() {
  const containerRef = useRef<HTMLDivElement>(null);
  const rpmNeedleRef = useRef<HTMLDivElement>(null);
  const boostNeedleRef = useRef<HTMLDivElement>(null);
  const rpmValueRef = useRef<HTMLDivElement>(null);
  const boostValueRef = useRef<HTMLDivElement>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    // Preload audio
    audioRef.current = new Audio('/engine-rev.mp3');
    audioRef.current.preload = 'auto';

    const createGaugeMarkers = (gauge: HTMLElement, max: number, isRPM: boolean) => {
      const totalMarkers = 100;
      const majorStep = isRPM ? 1000 : 5;
      
      for (let i = 0; i <= totalMarkers; i++) {
        const rotation = (i * (270 / totalMarkers)) - 225;
        const value = (i / totalMarkers) * max;
        
        const marker = document.createElement('div');
        marker.className = `gauge-marker ${value % majorStep === 0 ? 'major' : ''}`;
        marker.style.transform = `rotate(${rotation}deg)`;
        gauge.appendChild(marker);
        
        if (value % majorStep === 0) {
          const number = document.createElement('div');
          number.className = 'gauge-number';
          number.textContent = isRPM ? `${value/1000}` : `${value}`;
          number.style.transform = `rotate(${rotation}deg) translate(0, -70px) rotate(${-rotation}deg)`;
          gauge.appendChild(number);
        }
      }
    };

    const updateGauges = (rpm: number, boost: number) => {
      if (!rpmNeedleRef.current || !boostNeedleRef.current || !rpmValueRef.current || !boostValueRef.current) return;
      
      const rpmRotation = -225 + (rpm / 10000 * 270);
      rpmNeedleRef.current.style.transform = `translateX(-50%) rotate(${rpmRotation}deg)`;
      rpmValueRef.current.textContent = Math.round(rpm).toString();
      
      const boostRotation = -225 + (boost / 24 * 270);
      boostNeedleRef.current.style.transform = `translateX(-50%) rotate(${boostRotation}deg)`;
      boostValueRef.current.textContent = boost.toFixed(1);

      if (rpm >= 7500) {
        rpmNeedleRef.current.classList.add('redline');
      } else {
        rpmNeedleRef.current.classList.remove('redline');
      }
    };

    // Initialize gauge markers
    const rpmGauge = document.querySelector('.rpm-gauge .gauge-face');
    const boostGauge = document.querySelector('.boost-gauge .gauge-face');
    
    if (rpmGauge) createGaugeMarkers(rpmGauge as HTMLElement, 10000, true);
    if (boostGauge) createGaugeMarkers(boostGauge as HTMLElement, 24, false);

    const tl = gsap.timeline();

    // Intense drag racing rev sequence
    const revSequence = [
      { rpm: 1000, boost: 0, duration: 0.2 },    // Idle
      { rpm: 8500, boost: 20, duration: 0.3 },   // Launch
      { rpm: 6000, boost: 12, duration: 0.2 },   // Quick shift
      { rpm: 9500, boost: 24, duration: 0.3 },   // Second gear pull
      { rpm: 800, boost: 0, duration: 0.3 },     // Cut
    ];

    // Animation sequence
    tl.from('.gauge', {
      scale: 0,
      opacity: 0,
      duration: 0.5,
      stagger: 0.1,
      ease: 'back.out(1.7)'
    });

    // Add each rev point to the timeline
    revSequence.forEach((point, index) => {
      tl.to({}, {
        duration: point.duration,
        onStart: () => {
          if (index === 0 && audioRef.current) audioRef.current.play();
        },
        onUpdate: function() {
          const progress = this.progress();
          const prevPoint = index > 0 ? revSequence[index - 1] : { rpm: 0, boost: 0 };
          const currentRPM = prevPoint.rpm + (point.rpm - prevPoint.rpm) * progress;
          const currentBoost = prevPoint.boost + (point.boost - prevPoint.boost) * progress;
          updateGauges(currentRPM, currentBoost);
        }
      });
    });

    tl.to('.logo-container', {
      opacity: 1,
      scale: 1,
      duration: 0.5,
      ease: 'back.out(1.7)'
    }, '-=0.3')
    .to('.intro-container', {
      y: '-100%',
      duration: 0.8,
      ease: 'power4.inOut',
      delay: 0.5
    });

    // Cleanup
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);

  return (
    <div className="intro-container">
      <div className="flex items-center gap-8">
        <div className="gauge-container">
          <div className="gauge rpm-gauge">
            <div className="gauge-face"></div>
            <div ref={rpmNeedleRef} className="gauge-needle"></div>
            <div className="gauge-label">RPM x1000</div>
            <div ref={rpmValueRef} className="gauge-value">0</div>
          </div>
          <div className="gauge boost-gauge">
            <div className="gauge-face"></div>
            <div ref={boostNeedleRef} className="gauge-needle"></div>
            <div className="gauge-label">BOOST PSI</div>
            <div ref={boostValueRef} className="gauge-value">0.0</div>
          </div>
        </div>
        
        <div className="logo-container text-center opacity-0">
          <h1 className="text-7xl md:text-9xl font-bold">
            <span className="metal-gradient">ENVIOUS</span>
            <br />
            <span className="text-racing-red red-glow">RACING</span>
          </h1>
        </div>
      </div>
    </div>
  );
}