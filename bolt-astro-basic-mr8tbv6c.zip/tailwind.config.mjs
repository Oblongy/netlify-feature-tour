/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  theme: {
    extend: {
      colors: {
        'racing-red': '#ff0000',
        'racing-black': '#111111',
        'metal': '#d4d4d8',
        'neon-blue': '#00f3ff',
        'neon-purple': '#9d00ff',
      },
      fontFamily: {
        'racing': ['Racing Sans One', 'sans-serif'],
        'cyber': ['Share Tech Mono', 'monospace'],
      },
      animation: {
        'glow': 'glow 2s ease-in-out infinite',
        'pulse': 'pulse 2s infinite',
      },
      keyframes: {
        glow: {
          '0%, 100%': { filter: 'drop-shadow(0 0 2px rgba(255, 0, 0, 0.7))' },
          '50%': { filter: 'drop-shadow(0 0 10px rgba(255, 0, 0, 0.9))' },
        },
        pulse: {
          '0%, 100%': { transform: 'scale(1)', opacity: '1' },
          '50%': { transform: 'scale(1.2)', opacity: '0.8' },
        },
      },
    },
  },
  plugins: [],
}